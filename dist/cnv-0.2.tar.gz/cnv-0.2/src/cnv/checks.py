#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Do a sequence of checks on the parsed CNV data
"""

