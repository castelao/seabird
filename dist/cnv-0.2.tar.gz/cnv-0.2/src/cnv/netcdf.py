#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Export the parced data into a NetCDF following different patterns
"""

import pupynere
